$(document).ready(function() {
	$("#resultado_busca").load("../control/detalhes_pedido.php?acao=show");
});