<br /><br /><br /><br /><br />
<head>
	<script type="text/javascript" src="../js/detalhes_pedido.js"></script>
    <link rel="stylesheet" href="../css/general.css" media="screen" />
</head>
<div id="corpo">
    <div class="navigationBar">Request &#62;&#62; <strong>Request Details</strong></div>
	<div class="container">
		<div class="panel panel-success">
			<div class="panel-heading">Details Request</div>
			<table class="table table-hover table-bordered table-striped table-condensed">
	        <thead class="warning">
	          <tr class="warning">
	          	<td></td>
	            <td>Manager</th>
	            <td>Date</td>
	            <td>Partner</td>
	            <td>Status</td>
	          </tr>
	        </thead>
	        <tbody id="resultado_busca">
	          
	        </tbody>
	      </table>
		</div>
	</div>
</div>